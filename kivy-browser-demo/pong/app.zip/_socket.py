class socket:
    pass

AF_INET = 0
SOCK_STREAM = 0
