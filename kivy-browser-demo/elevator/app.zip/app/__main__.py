import os
os.environ['KIVY_NO_ARGS'] = '1'
os.environ['KIVY_NO_CONFIG'] = '1'
os.environ['KIVY_BUILD'] = 'emscripten'

import sys
sys.path.append('/app/nifty')


import runpy
runpy.run_path('/app/nifty/main.py', run_name='__main__')
