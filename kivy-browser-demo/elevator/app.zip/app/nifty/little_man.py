from kivy.event import EventDispatcher
from kivy import properties
from kivy.graphics import Color, Rectangle, PushMatrix, PopMatrix, Scale
from kivy.uix.image import Image
from sprite import Sprite, SpriteMixin


def bb_collision(a, b):
    aleft, abottom, aright, atop = a
    bleft, bbottom, bright, btop = b
    return not (
        aright < bleft or
        bright < aleft or
        abottom > btop or
        bbottom > atop
    )


class LittleMan(SpriteMixin, EventDispatcher):

    velocity = 0.1

    # Wait positions - where he can stop.
    wait_left = 1.5
    wait_right = 10.5

    # Limits to movement - at these points, he pops up to the next level
    limit_left = 0.5
    limit_right = 11.5

    pos_start = [wait_left, 0.0]

    pos = properties.ListProperty(pos_start)
    direction = properties.OptionProperty('stopped', options='left right up stopped'.split())
    platform = properties.NumericProperty(0)
    autopilot = properties.BooleanProperty(False)
    alive = properties.BooleanProperty(True)
    facing = properties.OptionProperty('right', options='left right'.split())

    def __init__(self, game, **kwargs):
        super(LittleMan, self).__init__(**kwargs)
        self.game = game

        ## TESTING LEVEL CHANGE:
        # start little man on last shelf
        #self.pos = [self.wait_right, 7.0]
        #self.platform = 7
        #
        ##

        self.register_event_type('on_reached_top')

    def get_sprite(self):
        sprite = Sprite()
        sprite.bind_to(self, pos='pos')

        def redraw(*_args):
            sprite.canvas.clear()

            with sprite.canvas:
                if self.facing == 'left':
                    Scale(-1, 1, 1)

                # TODO: lamb chops
                if not self.alive:
                    Color(0.7, 0, 0)
                    Rectangle(pos=(-0.25, 0), size=(0.7, 0.7))

                Image(source='sheep.png', pos=(-0.25, -0.05), size=(0.7, 0.7))

        # Redraw little man if the alive state changes
        self.bind(alive=redraw)

        # Redraw if the facing direction changes
        self.bind(facing=redraw)

        redraw()
        return sprite

    def pop_up(self):
        """Pop up to the next platform"""

        self.platform += 1
        self.direction = 'up'
        self.autopilot = True

    def wait(self):
        """Wait (at one of the wait positions)"""
        self.direction = 'stopped'
        self.autopilot = False

    def tick(self, _elapsed):
        if not self.alive:
            return
        self.move()
        self.collision_detect()

    def reset_row(self):
        leftbound = self.platform % 2
        x, y = self.pos
        self.pos = [self.wait_right if leftbound else self.wait_left, y]
        self.reset()

    def reset_level(self):
        self.pos = self.pos_start
        self.platform = 0
        self.reset()

    def reset(self):
        self.direction = 'stopped'
        self.autopilot = False

        leftbound = self.platform % 2
        self.facing = 'left' if leftbound else 'right'

        self.alive = True

    def collision_detect(self):
        for enemy in self.game.level.enemies:
            if any([bb_collision(self.bounding_box(), bb)
                    for bb in enemy.bounding_boxes()]):
                self.alive = False
                return

    def bounding_box(self):
        x, y = self.pos
        x -= 0.25
        y -= -0.05
        return x, y, x + 0.7, y + 0.7

    def move(self):
        x, y = self.pos

        leftbound = self.platform % 2
        if self.direction == 'right':
            # Move to the right
            x += self.velocity

            if x >= self.wait_right and leftbound:
                # Returned to right wait position on leftbound platform
                # Stop from moving any further right
                x = self.wait_right
                self.wait()

            elif x >= self.limit_right:
                # Reached the far right: pop up to next platform
                # (the previous case prevents this happening on leftbound platforms)
                x = self.limit_right
                self.pop_up()

            elif self.autopilot and x >= self.wait_left:
                # Just moved up to a rightbound platform - stop at left wait position
                x = self.wait_left
                self.wait()

        elif self.direction == 'left':
            # Move to the left
            x -= self.velocity

            if x <= self.wait_left and not leftbound:
                # Returned to left wait position on rightbound platform
                # Stop from moving any further left
                x = self.wait_left
                self.wait()

            elif x <= self.limit_left:
                # Reached the far left: pop up to next platform
                # (the previous case prevents this happening on rightbound platforms)
                x = self.limit_left
                self.pop_up()

            elif self.autopilot and x <= self.wait_right:
                # Just moved up to a leftbound platform - stop at right wait position
                x = self.wait_right
                self.wait()

        elif self.direction == 'up':
            # Move up
            y += self.velocity

            if y >= self.platform:
                # Stop at intended platform level
                y = self.platform

                if self.platform == 8.0:
                    # End of level
                    self.direction = 'stopped'
                    self.dispatch('on_reached_top')
                else:
                    # Move towards wait position
                    self.direction = 'left' if leftbound else 'right'
                    self.facing = 'left' if leftbound else 'right'

        self.pos = [x, y]

    def send(self, direction):
        if not self.autopilot:
            self.direction = direction

    def on_reached_top(self):
        pass
