from kivy import properties
from kivy.graphics.context_instructions import MatrixInstruction
from kivy.graphics.stencil_instructions import (
    StencilPush, StencilPop, StencilUse, StencilUnUse,
)
from kivy.graphics.transformation import Matrix
from kivy.graphics import Rectangle
from kivy.uix.widget import Widget


class FixedAspectRatioWidget(Widget):

    local_size = properties.ListProperty([1, 1])

    def __init__(self, **kwargs):
        self.bind(size=self.centre, pos=self.centre)
        super(FixedAspectRatioWidget, self).__init__(**kwargs)
        self.centre()

    def centre(self, *_args):
        self.canvas.before.clear()
        with self.canvas.before:
            lw, lh = self.local_size
            scale_w = float(self.width) / lw
            scale_h = float(self.height) / lh
            scale = min(scale_w, scale_h) * 0.99
            offset_x = self.x + (self.width - (lw * scale)) * 0.5
            offset_y = self.y + (self.height - (lh * scale)) * 0.5

            StencilPush()
            Rectangle(pos=(offset_x - 0.5, offset_y - 0.5),
                      size=(lw * scale + 1, lh * scale + 1))
            StencilUse()

            mat = Matrix()
            mat.translate(offset_x, offset_y, 0.0)
            mat.scale(scale, scale, 1.0)
            MatrixInstruction().matrix = mat

        self.canvas.after.clear()
        with self.canvas.after:
            StencilUnUse()
            Rectangle(pos=(offset_x, offset_y), size=(lw * scale + 1, lh * scale + 1))
            StencilPop()
