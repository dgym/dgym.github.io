from kivy import properties
from kivy.core.window import Window
from kivy.graphics import Color, Line, Rectangle

from widget import FixedAspectRatioWidget
from sprite import Sprite
from game import Game


class GameWidget(FixedAspectRatioWidget):
    local_size = properties.ListProperty([12.0, 8.0])
    game = properties.ObjectProperty(Game())
    gap = 1.0

    KEYS_LEFT = (276, ord('z'),)
    KEYS_RIGHT = (275, ord('x'),)
    TOUCH_THRESHOLD = 8

    def __init__(self, **kwargs):
        super(GameWidget, self).__init__(**kwargs)
        Window.bind(on_keyboard=self.on_keyboard)
        self.game.bind(on_level_changed=self.redraw)
        self.redraw()

    def on_keyboard(self, _sender, key, _scancode, _codepoint, _modifier):
        if key in self.KEYS_LEFT:
            self.game.little_man.send('left')
        elif key in self.KEYS_RIGHT:
            self.game.little_man.send('right')

    def on_touch_move(self, touch):
        if touch.dx < -self.TOUCH_THRESHOLD:
            self.game.little_man.send('left')
        elif touch.dx > self.TOUCH_THRESHOLD:
            self.game.little_man.send('right')

    def redraw(self, *_args, **_kwargs):
        game = self.game
        self.canvas.clear()
        with self.canvas:
            # Background
            Color(0.1, 0.1, 0.1)
            Rectangle(pos=(0, 0), size=(self.local_size[0], self.local_size[1]))

            # Platforms
            Color(1, 1, 1)
            line_width = 0.1
            for row in range(1, game.rows + 1):
                Rectangle(pos=(0 if row % 2 else 1, row - line_width),
                          size=(self.local_size[0] - 1, line_width))

            # Channels
            Color(0.1, 0.1, 0.1)
            for channel in game.level.channels:
                Rectangle(pos=(channel - 0.25, 0), size=(0.5, 12.0))

            # Outline
            #Color(0.2, 0.2, 0.2)
            #Line(rectangle=(0, 0, self.local_size[0], self.local_size[1]))


        self.canvas.add(game.little_man.sprite.canvas)

        for enemy in game.level.enemies:
            self.canvas.add(enemy.sprite.canvas)
