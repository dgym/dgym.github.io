from itertools import cycle, zip_longest

from kivy import properties
from kivy.event import EventDispatcher


import enemy


def interleave(*args):
    """Interleave any number of iterables"""

    return [item for pair in zip_longest(*args)
            for item in pair if item is not None]


def get_enemies(level):
    """Generate a list of enemies for the given level"""

    # LEVELS  CHANNELS
    # 1-2     1
    # 3-5     2
    # 6-9     3
    # 10-14   4

    # Thresholds determine the number of channels in a level
    # Level threshold is triangular number of that number of channels
    # e.g. for levels 6 and above there are 3 channels
    triangulars = ((n, (n * (n + 1) // 2)) for n in range(1, 10))
    num_channels, threshold = [(n, t) for n, t in triangulars if t <= level][-1]
    channels = [n + 1 for n in range(0, num_channels)]

    # Enemies that go up and down - one per channel
    enemies = [dict(channel=n, wrap=None) for n in channels]

    # For each level above the last threshold, add another wrapped enemy
    directions = 'down up up down'.split()

    # Re-order list of channels to work from the inside out
    # this is the order in which we will populate the channels
    mid = (num_channels) // 2
    inside_out = interleave(channels[mid:], reversed(channels[:mid]))
    inside_out = inside_out[:level - threshold]

    for direction, channel in zip(cycle(directions), inside_out):
        enemies.append(dict(wrap=direction, channel=channel))

    return enemies


def get_channel_positions(n):
    """Calculate channel positions based on number of channels"""

    gap = 1.25
    centre = 6.0

    # distance between first and last
    d = (gap * (n - 1))

    # position of first channel
    x = centre - (d / 2)
    return [x + (gap * i) for i in range(0, n)]


class NoSuchLevelError(Exception):
    pass


class Level(EventDispatcher):
    """Represents whatever the current level is"""

    level_number = properties.NumericProperty(1)

    # We run out of horizontal space after level 35
    MAX_LEVEL = 35

    def __init__(self):
        self.build_enemies()

    def up(self):
        """Bump up to next level"""

        if self.level_number == self.MAX_LEVEL:
            raise NoSuchLevelError()

        self.level_number += 1
        self.build_enemies()

    @property
    def enemy_info(self):
        return get_enemies(self.level_number)

    @property
    def channels(self):
        # work out number of channels for this level
        channels = [e['channel'] for e in self.enemy_info]
        num_channels = len(set(channels))
        return get_channel_positions(num_channels)

    def build_enemies(self):
        """Rebuild the enemy list"""
        def make_enemy(e):
            channel = self.channels[e['channel'] - 1]
            if e['wrap']:
                return enemy.WrappedEnemy(direction=e['wrap'], x=channel)
            else:
                return enemy.Enemy(x=channel)

        self.enemies = [make_enemy(e) for e in self.enemy_info]
