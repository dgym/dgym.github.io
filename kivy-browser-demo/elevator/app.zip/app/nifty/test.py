from time import sleep
import traceback
import subprocess
import os
import sys
import re

from kivy.config import Config
Config.set('graphics', 'multisamples', '0')
Config.setdefault('graphics', 'multisamples', '0')
import pygame

from kivy.core.window import Window
from kivy.base import EventLoop
from kivy.factory import Factory
from kivy.lang import Builder
from kivy.clock import Clock


def unregister_widget(class_name):
    # remove from the Factory
    Factory.classes.pop(class_name, None)
    # remove any Buildre rules
    rule_name = '<%s>' % class_name
    Builder.rules = [rule for rule in Builder.rules
        if rule[1].name != rule_name]


class Runner(object):
    def __init__(self, module, cls):
        self.module = module
        self.cls = cls
        self.exit = False
        self.app = None

    def start(self):
        del EventLoop.postproc_modules[:]
        del EventLoop.input_providers[:]
        cls = getattr(__import__(self.module), self.cls)
        self.app = cls()
        self.app.run()

    def stop(self):
        self.app.unbind()
        for child in Window.children:
            Window.remove_widget(child)
        self.app.stop()
        self.app = None

    def reload(self):
        # remove all local modules
        cwd = os.getcwd()
        for name, module in list(sys.modules.items()):
            if module \
                    and hasattr(module, '__file__') \
                    and module.__file__.startswith(cwd):
                # remove this module from Python
                del sys.modules[name]
                # remove any registered kivy Widgets
                for class_name, info in Factory.classes.items():
                    if isinstance(info['cls'], type) and \
                            info['cls'].__module__ == name:
                        unregister_widget(class_name)
        # delete clock events
        Clock._events.clear() # pylint: disable=W0212


def main():
    # pylint: disable=W0702

    # fix window size problems with tiling window managers
    EventLoop.ensure_window()
    window_id = pygame.display.get_wm_info()['wmwindow']
    try:
        stdout, _ = subprocess.Popen(
            ['xwininfo', '-id', str(window_id)],
            stdout=subprocess.PIPE
        ).communicate()
        width = int(re.search(r'Width: (\d+)', stdout).group(1))
        height = int(re.search(r'Width: (\d+)', stdout).group(1))
        Window.size = (width, height)
    except OSError:
        pass

    runner = Runner(sys.argv[1], sys.argv[2])

    def on_keyboard(_self, key, _scancode, _codepoint, _modifier):
        if key == 27:
            runner.stop()
            runner.exit = True
        elif key == 0x20:
            runner.stop()
            runner.reload()

    Window.bind(on_keyboard=on_keyboard)

    while not runner.exit:
        try:
            runner.start()
        except:
            traceback.print_exc()

            try:
                runner.stop()
            except:
                traceback.print_exc()

            try:
                runner.reload()
            except:
                traceback.print_exc()

            pygame.event.get()
            sleep(2.0)
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN and event.key == 27:
                    runner.exit = True
                    break


if __name__ == '__main__':
    main()
