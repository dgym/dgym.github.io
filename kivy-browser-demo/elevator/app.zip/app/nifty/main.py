import kivy
kivy.require('1.5.1')

from kivy.app import App
from kivy.core.window import Window
from kivy.uix.widget import Widget
from kivy.clock import Clock

# Required for .kv file
from game_widget import GameWidget


class NiftyScreen(Widget):
    pass


class NiftyApp(App):

    def build(self):
        self.screen = NiftyScreen()
        game = self.screen.game_widget.game

        Clock.schedule_interval(game.tick, 1 / 60.0)

        return self.screen

    def unbind(self):
        gw = self.screen.game_widget
        Window.unbind(on_keyboard=gw.on_keyboard)
        Window.unbind(on_touch_down=gw.on_touch_down)


# Fix the orientation
# TODO: make this common
try:
    import jnius
except ImportError:
    jnius = None

if jnius:
    PythonActivity = jnius.autoclass('org.renpy.android.PythonActivity')
    ActivityInfo = jnius.autoclass('android.content.pm.ActivityInfo')
    activity = jnius.cast('android.app.Activity', PythonActivity.mActivity)
    activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)


if __name__ in ('__main__', '__android__'):
    NiftyApp().run()
