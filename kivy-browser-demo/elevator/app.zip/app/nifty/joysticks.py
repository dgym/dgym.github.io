from kivy import properties
from kivy.event import EventDispatcher

import pygame

try:
    from jnius import autoclass
except ImportError:
    autoclass = None

#from simple_signal import SimpleSignal


class Joystick(object):
    def __init__(self):
        self.buttons = []
        #self.on_button_down = SimpleSignal()
        #self.on_button_up = SimpleSignal()

        self.axis = []
        #self.on_axis_changed = SimpleSignal()


class PygameJoystick(object):
    def __init__(self, obj):
        super(PygameJoystick, self).__init__()


class Controller(object):
    DIRECTION  = 0
    NUM_INPUTS = 1

    def __init__(self):
        self.values = [None] * self.NUM_INPUTS
        self.old_values = [None] * self.NUM_INPUTS

    def get(self, key):
        return self.values[key]

    def changed(self, key):
        return self.values[key] != self.old_values[key]

    def pressed(self, key):
        return self.get(key) and self.changed(key)

    def read(self):
        self.values, self.old_values = self.old_values, self.values


class PygameController(Controller):
    def __init__(self, joystick):
        super(PygameController, self).__init__()
        self.joystick = joystick


class TwinUSBController(PygameController):
    def read(self):
        super(TwinUSBController, self).read()
        values = self.values
        joystick = self.joystick
        lr = joystick.get_axis(0)
        if -0.12 < lr < 0.12:
            lr = 0.0
        values[self.DIRECTION] = lr


class PS3USBController(PygameController):
    def read(self):
        # 13 = circle
        super(PS3USBController, self).read()
        values = self.values
        joystick = self.joystick
        lr = joystick.get_axis(0)
        if -0.12 < lr < 0.12:
            lr = 0.0
        values[self.DIRECTION] = lr


class OuyaController(Controller):
    def __init__(self, ouya_controller, player):
        super(OuyaController, self).__init__()
        self.ouya_controller = ouya_controller
        self.player = player

    def read(self):
        super(OuyaController, self).read()
        values = self.values
        oc = self.ouya_controller
        joystick = ou.getControllerByPlayer(self.player)
        lr = joystick.getAxisValue(oc.AXIS_LS_X)
        if -0.22 < lr < 0.22:
            lr = 0.0
        values[self.DIRECTION] = lr


class Joysticks(list):
    def __init__(self):
        if autoclass:
            self.setup_ouya()
        else:
            self.setup_pygame()

    def setup_pygame(self):
        if not hasattr(pygame, 'actually_been_here_before'):
            pygame.joystick.init()

        for idx in range(pygame.joystick.get_count()):
            joystick = pygame.joystick.Joystick(idx)
            if not hasattr(pygame, 'actually_been_here_before'):
                joystick.init()
            if joystick.get_numaxes() > 0 and joystick.get_numbuttons() > 3:
                name = joystick.get_name()
                if name == 'Twin USB Joystick':
                    self.append(TwinUSBController(joystick))
                elif name == 'Sony PLAYSTATION(R)3 Controller':
                    self.append(PS3USBController(joystick))
                else:
                    print('Unrecognised joystick:%s', name)
        pygame.actually_been_here_before = True

    def setup_ouya(self):
        ouya_controller = autoclass('tv.ouya.console.api.OuyaController')
        for idx in range(4):
            self.append(OuyaController(ouya_controller, idx))
