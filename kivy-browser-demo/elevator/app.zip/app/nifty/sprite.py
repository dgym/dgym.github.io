from kivy.event import EventDispatcher
from kivy import properties
from kivy.graphics.instructions import Canvas
from kivy.graphics.context_instructions import (
    MatrixInstruction, PushMatrix, PopMatrix,
)
from kivy.graphics.transformation import Matrix


class Sprite(EventDispatcher):
    pos = properties.ListProperty([0, 0])
    rot = properties.NumericProperty(0.0)

    def __init__(self, **kwargs):
        self.canvas = Canvas()

        with self.canvas.before:
            PushMatrix()
            self._transform = MatrixInstruction()

        with self.canvas.after:
            PopMatrix()

        self.bind(pos=self.update_matrix, rot=self.update_matrix)
        super(Sprite, self).__init__(**kwargs)

    def bind_to(self, other, **kwargs):
        for ours, theirs in kwargs.items():
            def make_setter(ours):
                setattr(self, ours, getattr(other, theirs))
                def on_set(_, value):
                    setattr(self, ours, value)
                return on_set
            other.bind(**{theirs: make_setter(ours)})

    def update_matrix(self, *_args):
        mat = Matrix()
        mat.translate(self.pos[0], self.pos[1], 0)
        mat.rotate(self.rot, 0, 0, 1)
        self._transform.matrix = mat


class SpriteMixin(object):
    _sprite = None

    @property
    def sprite(self):
        if self._sprite is None:
            self._sprite = self.get_sprite()
        return self._sprite

    @sprite.setter
    def sprite(self, value):
        self._sprite = value

    def get_sprite(self):
        return Sprite()
