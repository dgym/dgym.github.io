import random

from kivy import properties
from kivy.event import EventDispatcher
from kivy.graphics import Color, Rectangle

from sprite import Sprite, SpriteMixin


class Enemy(SpriteMixin, EventDispatcher):
    pos = properties.ListProperty([6, 0])
    direction = properties.OptionProperty('up', options='up down'.split())
    wrap = properties.BooleanProperty(False)

    top = 7.5
    bottom = 0.0
    velocity = 0.1

    def __init__(self, x, **kwargs):
        self.pos = [x, self.bottom + random.random() * (self.top - self.bottom)]
        super(EventDispatcher, self).__init__(**kwargs)

    def __str__(self):
        return '<Enemy (%s)>' % self.pos

    def bounding_boxes(self):
        x, y = self.pos
        x -= 0.25
        return [[x, y, x + 0.5, y + 0.5], ]

    def tick(self, elapsed):
        x, y = self.pos

        if self.direction == 'up':
            y += self.velocity

            if y >= self.top:
                y = self.top
                self.direction = 'down'

        elif self.direction == 'down':
            y -= self.velocity

            if y <= self.bottom:
                y = self.bottom
                self.direction = 'up'

        self.pos = [x, y]

    def get_sprite(self):
        sprite = Sprite()
        sprite.bind_to(self, pos='pos')
        with sprite.canvas:
            Color(1, 1, 0)
            Rectangle(pos=(-0.25, 0), size=(0.5, 0.5))
        return sprite


class WrappedEnemy(Enemy):

    def __init__(self, direction, **kwargs):
        self.direction = direction
        super(WrappedEnemy, self).__init__(**kwargs)

    def get_sprite(self):
        sprite = Sprite()
        sprite.bind_to(self, pos='pos')
        with sprite.canvas:
            Color(0, 0, 1)
            Rectangle(pos=(-0.25, 0), size=(0.5, 0.5))

            # Trailing box simulates wrapped around state
            # (when box is half off the bottom/top)
            Rectangle(pos=(-0.25, -self.top - 0.5), size=(0.5, 0.5))
        return sprite

    def bounding_boxes(self):
        boxes = super(WrappedEnemy, self).bounding_boxes()
        offset = self.top + 0.5

        left, bottom, right, top = boxes[0]
        boxes.append([left, bottom - offset, right, top - offset])
        return boxes

    def tick(self, elapsed):
        x, y = self.pos

        if self.direction == 'up':
            y += self.velocity

            if y >= self.top + 0.5:
                # All the way off the top - loop around to the bottom
                y = self.bottom

        elif self.direction == 'down':
            y -= self.velocity

            if y <= self.bottom - 0.5:
                # All the way off the bottom - loop around to the top
                y = self.top

        self.pos = [x, y]
