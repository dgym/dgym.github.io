from kivy import properties
from kivy.clock import Clock
from kivy.event import EventDispatcher

from little_man import LittleMan

#from joysticks import Joysticks
from levels import Level, NoSuchLevelError


class Game(EventDispatcher):
    level = properties.ObjectProperty(Level())

    rows = 8
    lives = properties.NumericProperty(3)

    def __init__(self, **kwargs):
        super(Game, self).__init__(**kwargs)

        self.little_man = LittleMan(direction='stopped', game=self)
        self.little_man.bind(on_reached_top=self.level_up)
        self.little_man.bind(alive=self.on_alive_changed)

        self.register_event_type('on_level_changed')
        self.register_event_type('on_game_over')
        self.register_event_type('on_game_complete')

        # Set up joysticks
        #self.joysticks = Joysticks()


    def on_alive_changed(self, little_man, alive):
        if not alive:
            def continue_game(*_args):
                self.lives -= 1
                if self.lives == 0:
                    self.dispatch('on_game_over')

                little_man.reset_row()

            Clock.schedule_once(continue_game, 1)

    def level_up(self, obj):
        def change_level(*_args):
            try:
                self.lives += 1
                self.level.up()
                self.little_man.reset_level()
                self.dispatch('on_level_changed')
            except NoSuchLevelError:
                # Completed all levels
                self.dispatch('on_game_complete')

        Clock.schedule_once(change_level, 1)

#    def read_joysticks(self):
#
#        # read joysticks
#        for idx, joystick in enumerate(self.joysticks):
#            if joystick is None:
#                continue
#            joystick.read()
#            lr = joystick.get(joystick.DIRECTION)
#
#            if lr < 0:
#                self.little_man.send('left')
#            elif lr > 0:
#                self.little_man.send('right')


    def tick(self, elapsed):

        elapsed = 1 / 25.0
        self.little_man.tick(elapsed)
        for enemy in self.level.enemies:
            enemy.tick(elapsed)

#        self.read_joysticks()

    def on_level_changed(self):
        pass

    def on_game_over(self):
        print('GAME OVER')

    def on_game_complete(self):
        print('WELL DONE')
