import os
os.environ['KIVY_NO_ARGS'] = '1'
os.environ['KIVY_NO_CONFIG'] = '1'
os.environ['KIVY_BUILD'] = 'emscripten'

import sys
sys.path.append('/app/monkey3d')


import runpy
runpy.run_path('/app/monkey3d/main.py', run_name='__main__')
