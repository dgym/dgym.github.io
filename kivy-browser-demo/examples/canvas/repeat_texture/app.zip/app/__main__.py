import os
os.environ['KIVY_NO_ARGS'] = '1'
os.environ['KIVY_NO_CONFIG'] = '1'
os.environ['KIVY_BUILD'] = 'emscripten'

APP_NAME = 'canvas'

import sys
os.chdir('/app/%s' % APP_NAME)
sys.path.append('/app/%s' % APP_NAME)
sys.path.append('.')


import runpy
runpy.run_path('repeat_texture.py', run_name='__main__')
